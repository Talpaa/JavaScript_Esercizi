let nome = "mario";

console.log("Ciao " + nome);