let x = 10;

let y = x;

let z = "mario";

console.log(x + " " + typeof x + "\n");

console.log(y + " " + typeof y + "\n");

console.log(z + " " + typeof z + "\n");