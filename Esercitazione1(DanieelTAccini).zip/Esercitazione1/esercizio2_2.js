console.log("Primo esercizio JavaScript")

let numero = 100;

console.log("Valore iniziale: " + numero);

numero = 70;

console.log("Valore finale: " + numero);