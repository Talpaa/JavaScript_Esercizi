let giorniDellaSettimana = " Lunedì, Martedì, Mercoledì, Giovedì, venerdì, Sabato, Domenica";

console.log(giorniDellaSettimana);

console.log(giorniDellaSettimana.replaceAll(",", "\n"));